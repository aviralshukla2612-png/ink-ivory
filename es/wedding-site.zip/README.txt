Wedding invitation website (Arun Kumar & Meenakshi Priya)

HOW TO USE
1. Keep index.html and the images folder together.
2. Open index.html in a browser, or upload both to any web host (Netlify, GitHub Pages, etc).

HOW TO CUSTOMISE (all inside index.html)
- Names, dates, venue and families: search for "Arun", "Meenakshi", "AVM Rajeswari" and edit the text.
- Countdown date: change  var WEDDING=new Date("2027-01-26T09:00:00+05:30");  near the bottom.
- Pictures: replace the files in the images folder (keep the same file names), or edit the IMAGES list near the bottom.
- Background music: paste an .mp3 link into  var MUSIC_URL="";
- Maps button: change the link in the "Search venue in maps" button.
